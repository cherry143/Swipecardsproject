//
//  SwipeDM.swift
//  Swipestaticdt
//

//

import UIKit

struct SwipeDM {
    var name : String
    var designation : String
    var image : String
    
    init(name : String, designation : String, image : String) {
        self.name = name
        self.designation = designation
        self.image = image
    }
}
