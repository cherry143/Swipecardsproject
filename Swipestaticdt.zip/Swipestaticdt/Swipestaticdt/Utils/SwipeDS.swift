//
//  SwipeDS.swift
//  Swipestaticdt
//
//  Created by Badari on 22/09/20.



import UIKit

protocol SwipeDS {
    func numberOfCardsToShow() -> Int
    func card(at index: Int) -> Swipeview
    func emptyView() -> UIView?
    
}

protocol SwipeCardsDelegate {
    func swipeDidEnd(on view: Swipeview)
}
