//
//  ViewController.swift
//  Swipestaticdt
//
//  
//

import UIKit

class ViewController: UIViewController {

    //MARK: - Properties
        
    
    var viewModelData = [SwipeDM(name: "Alex", designation: "Developer", image: "male"),SwipeDM(name: "Fraancis", designation: "Civil Engineer", image: "male"),SwipeDM(name: "Thomson", designation: "Vendor", image: "male"),SwipeDM(name: "Akai", designation: "Operator", image: "male"),SwipeDM(name: "Bob", designation: "Computer Operator", image: "male")]
    
    var stackContainer : Swipecontainerview!
      
        
        //MARK: - Init
        
        override func loadView() {
            view = UIView()
            view.backgroundColor = UIColor(red:0.93, green:0.93, blue:0.93, alpha:1.0)
            stackContainer = Swipecontainerview()
            view.addSubview(stackContainer)
            configureStackContainer()
            stackContainer.translatesAutoresizingMaskIntoConstraints = false
            configureNavigationBarButtonItem()
        }
     
        override func viewDidLoad() {
            super.viewDidLoad()
            title = "Personal Data"
            stackContainer.dataSource = self as? SwipeDS
        }
        
     
        //MARK: - Configurations
        func configureStackContainer() {
            stackContainer.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
            stackContainer.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -60).isActive = true
            stackContainer.widthAnchor.constraint(equalToConstant: 300).isActive = true
            stackContainer.heightAnchor.constraint(equalToConstant: 400).isActive = true
        }
        
        func configureNavigationBarButtonItem() {
            navigationItem.rightBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: self, action: #selector(resetTapped))
        }
        
        //MARK: - Handlers
        @objc func resetTapped() {
            stackContainer.reloadData()
        }

    }

    extension ViewController : SwipeDS {

        func numberOfCardsToShow() -> Int {
            return viewModelData.count
        }
        
        func card(at index: Int) -> Swipeview {
            let card = Swipeview()
            card.dataSource = viewModelData[index]
            return card
        }
        
        func emptyView() -> UIView? {
            return nil
        }



}

